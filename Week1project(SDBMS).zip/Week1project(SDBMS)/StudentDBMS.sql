-- Created Database as SDMS1
CREATE DATABASE SDMS1;

USE SDMS1;

-- Created studentin table 
CREATE TABLE studentin (
    rollno INT PRIMARY KEY,
    name VARCHAR(50),
    address VARCHAR(30),
    contact INT UNIQUE,
    year_of_admission INT,
    course_enrolled_name VARCHAR(20),
    attendance_date DATE,
    attendance_status VARCHAR(20),
    grade VARCHAR(5),
    fee_amount DECIMAL(10,2),
    payment_date DATE,
    scholarship_type VARCHAR(30),
    scholarship_amount DECIMAL(10,2)
);

-- Inserting data into the studentin table
INSERT INTO studentin (rollno, name, address, contact, year_of_admission, course_enrolled_name, attendance_date, attendance_status, grade, fee_amount, payment_date, scholarship_type, scholarship_amount) 
VALUES 
(1, 'Shruti Padwal', 'Shukrawar Peth', 947932932, 2023, 'Computer Science', '2023-01-10', 'Present', 'A', 1000.00, '2024-01-10', 'Merit', 500.00),
(2, 'Priya Singh', 'Bhawani Peth', 987653210, 2022, 'Science', '2024-02-10', 'Present', 'B', 1200.00, '2024-01-25', 'Athletic', 300.00),
(3, 'Atharva Nija', 'Ganesh Peth', 987641230, 2024, 'Mathematics', '2024-02-11', 'Present', 'A', 1100.00, '2024-01-28', 'Merit', 600.00),
(4, 'Bob Brown', 'Shukrawar Peth', 987136540, 2023, 'History', '2024-02-11', 'Absent', 'C', 1000.00, '2024-01-29', 'Athletic', 300.00),
(5, 'Arpita Newaskar', 'Raviwar Peth', 32167890, 2022, 'Science', '2024-02-13', 'Present', 'A', 1200.00, '2024-01-27', 'Merit', 500.00),
(6, 'Shraddha Badhe', 'Bhawani Peth', 12347890, 2023, 'Mathematics', '2024-02-10', 'Present', 'A', 1000.00, '2024-01-30', 'Merit', 500.00),
(7, 'Janvi Jadhav', 'Hadapsar', 45670123, 2023, 'Physical Education', '2024-02-10', 'Present', 'B', 900.00, '2024-01-20', 'Sports', 400.00),
(8, 'Coco Dev', 'Shukrawar Peth', 789013456, 2024, 'Literature', '2024-02-13', 'Present', 'A', 1000.00, '2024-01-22', 'Merit', 500.00),
(9, 'Om Jadhav', 'Sadashiv Peth', 567801234, 2022, 'Science', '2024-02-10', 'Absent', 'C', 1500.00, '2024-01-29', 'Sports', 400.00),
(10, 'Kunal Prajapati', 'Hadapsar', 89034567, 2022, 'Electronics', '2024-02-11', 'Absent', 'B', 1300.00, '2024-01-28', 'Sports', 400.00),
(11, 'Ankita Pawar', 'Ganesh Peth', 90123478, 2023, 'Electronics', '2024-02-10', 'Present', 'A', 1300.00, '2024-01-28', 'Sports', 600.00),
(12, 'Anuja Gadade', 'Shaniwar Peth', 345689012, 2022, 'Racing', '2024-02-02', 'Present', 'B', 1100.00, '2024-01-26', 'Sports', 300.00),
(13, 'Lionel Messi', 'Raviwar Peth', 23458901, 2024, 'Soccer', '2024-02-10', 'Present', 'A', 1500.00, '2024-01-25', 'Merit', 700.00),
(14, 'Roger Federer', 'Katraj', 67892345, 2023, 'Tennis', '2024-02-13', 'Present', 'A', 1400.00, '2024-01-29', 'Sports', 500.00),
(15, 'Rafael Nadal', 'Katraj', 89012567, 2022, 'Tennis', '2024-02-12', 'Absent', 'C', 1300.00, '2024-01-28', 'Athletic', 300.00);
-- Select * shows all the columns in the table
select * from studentin;

-- count total admissions in 2022,23,24 and get their name, course_enrolled_name, grade, scholarship_type from the table
select count(rollno) from studentin
where year_of_admission = "2022";
select name,course_enrolled_name, grade,scholarship_type from studentin
where year_of_admission = "2022" ;

select count(rollno) from studentin
where year_of_admission = "2023";
select name,course_enrolled_name, grade,scholarship_type from studentin
where year_of_admission = "2023" ;

select count(rollno) from studentin
where year_of_admission = "2024";
select name,course_enrolled_name, grade,scholarship_type from studentin
where year_of_admission = "2024" ;

-- find the how many students have enrolled the course for each course 
select course_enrolled_name, count(*) from studentin
group by course_enrolled_name;

-- count no of enrolled courses uniquely
select count(distinct course_enrolled_name) from studentin;

-- find each year how many people were "present"
select year_of_admission, count(*) from studentin
where attendance_status = "Present"
group by year_of_admission;

-- no of student receiving scholarshps
select scholarship_type, count(*) from studentin
group by scholarship_type;

-- no of students from a particular address
select address, count(*)from studentin
group by address;

-- count unique addresses 
select count(distinct address) from studentin;

-- Attendence report showing the attendance status of all students on a specific date.
select name, attendance_status from studentin
where attendance_date = "2024-02-10";

-- How many students are enrolled in the "Science" course?
select count(rollno) from studentin
where course_enrolled_name = "Science";

-- Which student has the highest fee amount paid?
select * from studentin
order by fee_amount desc
limit 1;

-- How many students were present on '2024-02-10'?
select count(rollno) from studentin
where attendance_date = "2024-02-10" and attendance_status = "Present";
